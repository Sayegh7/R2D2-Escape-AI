# Files to edit:
```
State.py
TransitionFunction.py
```
# Define:
- Problem's Operators
- Problem's goalTestFunction

# Installation:
Make sure you have python3 and pip3 installed then cd into the project directory and run the following:
```
pip3 install -r requirements.txt
```
# Usage:
To use this project:
```
python3 index.py
```
