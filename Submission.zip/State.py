class State():
    def __init__(self, x, y ,grid, max,max_depth=999999999):
        self.x = x
        self.y = y
        self.grid = grid
        self.max = max
        self.max_depth =max_depth
